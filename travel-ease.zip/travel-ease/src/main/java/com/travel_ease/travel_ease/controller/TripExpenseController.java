package com.travel_ease.travel_ease.controller;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.travel_ease.travel_ease.entity.TripExpense;
import com.travel_ease.travel_ease.service.TripExpenseService;

@RestController
@RequestMapping("/api/trip-expenses")
public class TripExpenseController {

    @Autowired
    private TripExpenseService tripExpenseService;

    // E1
    @PostMapping("/save")
    public ResponseEntity<String> saveTripExpense(@RequestParam UUID tripPlanId, @RequestBody TripExpense tripExpense) {
        String message = tripExpenseService.saveTripExpense(tripPlanId, tripExpense);
        if (message.equals("The trip plan with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else if (message.equals("Trip expenses are only for TRAVELLED trip plans")) {
            return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
        } else {
            return new ResponseEntity<>(message, HttpStatus.CREATED);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<TripExpense>> getAllTripExpenses() {
        return new ResponseEntity<>(tripExpenseService.getAllTripExpenses(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTripExpenseById(@PathVariable UUID id) {
        Optional<TripExpense> tripExpense = tripExpenseService.getTripExpenseById(id);
        if (tripExpense.isPresent()) {
            return new ResponseEntity<>(tripExpense.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("The trip expense with that id does not exist", HttpStatus.NOT_FOUND);
        }
    }

    // E2
    @GetMapping("/traveler/{passportNumber}")
    public ResponseEntity<List<TripExpense>> getTripExpensesOfTraveler(@PathVariable String passportNumber) {
        return new ResponseEntity<>(tripExpenseService.getTripExpensesOfTraveler(passportNumber), HttpStatus.OK);
    }

    // E3
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTripExpense(@PathVariable UUID id) {
        String message = tripExpenseService.deleteTripExpense(id);
        if (message.equals("The trip expense with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }
}
