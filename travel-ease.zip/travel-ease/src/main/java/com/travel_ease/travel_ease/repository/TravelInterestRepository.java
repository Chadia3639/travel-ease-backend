package com.travel_ease.travel_ease.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.travel_ease.travel_ease.entity.TravelInterest;

@Repository
public interface TravelInterestRepository extends JpaRepository<TravelInterest, UUID> {

    // C3
    @Query("SELECT c FROM TravelInterest c WHERE c.agents IS EMPTY")
    List<TravelInterest> findUnusedTravelInterests();
}
