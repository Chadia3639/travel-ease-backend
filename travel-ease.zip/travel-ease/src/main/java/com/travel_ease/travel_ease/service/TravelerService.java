package com.travel_ease.travel_ease.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel_ease.travel_ease.entity.Traveler;
import com.travel_ease.travel_ease.repository.TravelerRepository;

@Service
public class TravelerService {

    @Autowired
    private TravelerRepository travelerRepository;

    public String saveTraveler(Traveler traveler) {
        travelerRepository.save(traveler);
        return "Traveler saved successfully";
    }

    public List<Traveler> getAllTravelers() {
        return travelerRepository.findAll();
    }

    public Optional<Traveler> getTravelerById(UUID id) {
        return travelerRepository.findById(id);
    }

    public String updateTraveler(UUID id, Traveler traveler) {
        Optional<Traveler> existing = travelerRepository.findById(id);
        if (existing.isEmpty()) {
            return "The traveler with that id does not exist";
        }
        Traveler found = existing.get();
        found.setFirstName(traveler.getFirstName());
        found.setLastName(traveler.getLastName());
        found.setPassportNumber(traveler.getPassportNumber());
        found.setEmail(traveler.getEmail());
        found.setNationality(traveler.getNationality());
        travelerRepository.save(found);
        return "Traveler updated successfully";
    }

    public String deleteTraveler(UUID id) {
        if (!travelerRepository.existsById(id)) {
            return "The traveler with that id does not exist";
        }
        travelerRepository.deleteById(id);
        return "Traveler deleted successfully";
    }

    // B1
    public List<Traveler> getTravelersByNationality(String nationality) {
        return travelerRepository.findByNationalityIgnoreCaseOrderByLastNameAsc(nationality);
    }

    // C4
    public List<Traveler> getTravelersOfTravelAgent(UUID travelAgentId) {
        return travelerRepository.findTravelersOfTravelAgent(travelAgentId);
    }
}
