package com.travel_ease.travel_ease.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel_ease.travel_ease.entity.TripExpense;
import com.travel_ease.travel_ease.entity.TripPlan;
import com.travel_ease.travel_ease.entity.TripStatus;
import com.travel_ease.travel_ease.repository.TripExpenseRepository;
import com.travel_ease.travel_ease.repository.TripPlanRepository;

@Service
public class TripExpenseService {

    @Autowired
    private TripExpenseRepository tripExpenseRepository;

    @Autowired
    private TripPlanRepository tripPlanRepository;

    // E1
    public String saveTripExpense(UUID tripPlanId, TripExpense tripExpense) {
        Optional<TripPlan> tripPlan = tripPlanRepository.findById(tripPlanId);
        if (tripPlan.isEmpty()) {
            return "The trip plan with that id does not exist";
        }
        if (tripPlan.get().getStatus() != TripStatus.TRAVELLED) {
            return "Trip expenses are only for TRAVELLED trip plans";
        }
        tripExpense.setRecordedDate(LocalDate.now());
        tripExpense.setTripPlan(tripPlan.get());
        tripExpenseRepository.save(tripExpense);
        return "Trip expense saved successfully";
    }

    public List<TripExpense> getAllTripExpenses() {
        return tripExpenseRepository.findAll();
    }

    public Optional<TripExpense> getTripExpenseById(UUID id) {
        return tripExpenseRepository.findById(id);
    }

    // E2
    public List<TripExpense> getTripExpensesOfTraveler(String passportNumber) {
        return tripExpenseRepository.findByTravelerPassportNumber(passportNumber);
    }

    // E3
    public String deleteTripExpense(UUID id) {
        if (!tripExpenseRepository.existsById(id)) {
            return "The trip expense with that id does not exist";
        }
        tripExpenseRepository.deleteById(id);
        return "Trip expense deleted successfully";
    }
}
