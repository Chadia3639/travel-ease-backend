package com.travel_ease.travel_ease.controller;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.travel_ease.travel_ease.entity.TravelInterest;
import com.travel_ease.travel_ease.service.TravelInterestService;

@RestController
@RequestMapping("/api/travel-interests")
public class TravelInterestController {

    @Autowired
    private TravelInterestService travelInterestService;

    @PostMapping("/save")
    public ResponseEntity<String> saveTravelInterest(@RequestBody TravelInterest travelInterest) {
        String message = travelInterestService.saveTravelInterest(travelInterest);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<TravelInterest>> getAllTravelInterests() {
        return new ResponseEntity<>(travelInterestService.getAllTravelInterests(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTravelInterestById(@PathVariable UUID id) {
        Optional<TravelInterest> travelInterest = travelInterestService.getTravelInterestById(id);
        if (travelInterest.isPresent()) {
            return new ResponseEntity<>(travelInterest.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("The travel interest with that id does not exist", HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateTravelInterest(@PathVariable UUID id, @RequestBody TravelInterest travelInterest) {
        String message = travelInterestService.updateTravelInterest(id, travelInterest);
        if (message.equals("The travel interest with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTravelInterest(@PathVariable UUID id) {
        String message = travelInterestService.deleteTravelInterest(id);
        if (message.equals("The travel interest with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // C3
    @GetMapping("/unused")
    public ResponseEntity<List<TravelInterest>> getUnusedTravelInterests() {
        return new ResponseEntity<>(travelInterestService.getUnusedTravelInterests(), HttpStatus.OK);
    }
}
