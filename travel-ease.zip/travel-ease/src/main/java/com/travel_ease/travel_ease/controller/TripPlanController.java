package com.travel_ease.travel_ease.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.travel_ease.travel_ease.entity.TripPlan;
import com.travel_ease.travel_ease.entity.TripStatus;
import com.travel_ease.travel_ease.service.TripPlanService;

@RestController
@RequestMapping("/api/trip-plans")
public class TripPlanController {

    @Autowired
    private TripPlanService tripPlanService;

    @PostMapping("/save")
    public ResponseEntity<String> saveTripPlan(@RequestBody TripPlan tripPlan) {
        String message = tripPlanService.saveTripPlan(tripPlan);
        if (message.equals("Trip plan date cannot be in the past")) {
            return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
        } else if (message.equals("Travel agent already has a departure on that date")) {
            return new ResponseEntity<>(message, HttpStatus.CONFLICT);
        } else {
            return new ResponseEntity<>(message, HttpStatus.CREATED);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<TripPlan>> getAllTripPlans() {
        return new ResponseEntity<>(tripPlanService.getAllTripPlans(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTripPlanById(@PathVariable UUID id) {
        Optional<TripPlan> tripPlan = tripPlanService.getTripPlanById(id);
        if (tripPlan.isPresent()) {
            return new ResponseEntity<>(tripPlan.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("The trip plan with that id does not exist", HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateTripPlan(@PathVariable UUID id, @RequestBody TripPlan tripPlan) {
        String message = tripPlanService.updateTripPlan(id, tripPlan);
        if (message.equals("The trip plan with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // D2
    @PatchMapping("/{id}/status")
    public ResponseEntity<String> changeTripPlanStatus(@PathVariable UUID id, @RequestParam TripStatus status) {
        String message = tripPlanService.changeTripPlanStatus(id, status);
        if (message.equals("The trip plan with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else if (message.startsWith("Cannot change status from")) {
            return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // Bonus: sort comes as "field,direction", e.g. departureDate,desc
    @GetMapping("/page")
    public ResponseEntity<Page<TripPlan>> getTripPlansPage(@RequestParam int page, @RequestParam int size, @RequestParam String sort) {
        String[] sortParts = sort.split(",");
        Sort.Direction direction = Sort.Direction.ASC;
        if (sortParts.length > 1 && sortParts[1].equalsIgnoreCase("desc")) {
            direction = Sort.Direction.DESC;
        }
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortParts[0]));
        return new ResponseEntity<>(tripPlanService.getTripPlansPage(pageable), HttpStatus.OK);
    }

    // F1
    @GetMapping("/stats/by-status")
    public ResponseEntity<List<Object[]>> getTripPlanCountPerStatus() {
        return new ResponseEntity<>(tripPlanService.getTripPlanCountPerStatus(), HttpStatus.OK);
    }

    // F2
    @PatchMapping("/cancel-day")
    public ResponseEntity<String> cancelDayOfTravelAgent(@RequestParam UUID travelAgentId, @RequestParam String date) {
        LocalDate day = LocalDate.parse(date);
        return new ResponseEntity<>(tripPlanService.cancelDayOfTravelAgent(travelAgentId, day), HttpStatus.OK);
    }

    // B2
    @GetMapping("/by-status")
    public ResponseEntity<List<TripPlan>> getTripPlansByStatus(@RequestParam TripStatus status) {
        return new ResponseEntity<>(tripPlanService.getTripPlansByStatus(status), HttpStatus.OK);
    }

    // B3
    @GetMapping("/between")
    public ResponseEntity<List<TripPlan>> getTripPlansBetween(@RequestParam String start, @RequestParam String end) {
        LocalDate startDate = LocalDate.parse(start);
        LocalDate endDate = LocalDate.parse(end);
        return new ResponseEntity<>(tripPlanService.getTripPlansBetween(startDate, endDate), HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTripPlan(@PathVariable UUID id) {
        String message = tripPlanService.deleteTripPlan(id);
        if (message.equals("The trip plan with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else if (message.equals("That trip plan has trip expenses, delete them first")) {
            return new ResponseEntity<>(message, HttpStatus.CONFLICT);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }
}
