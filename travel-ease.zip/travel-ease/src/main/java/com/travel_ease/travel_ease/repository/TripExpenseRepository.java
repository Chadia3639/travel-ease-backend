package com.travel_ease.travel_ease.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.travel_ease.travel_ease.entity.TripExpense;
import com.travel_ease.travel_ease.entity.TripPlan;

@Repository
public interface TripExpenseRepository extends JpaRepository<TripExpense, UUID> {

    // E2
    @Query("SELECT d FROM TripExpense d WHERE d.tripPlan.traveler.passportNumber = :passportNumber ORDER BY d.recordedDate DESC")
    List<TripExpense> findByTravelerPassportNumber(@Param("passportNumber") String passportNumber);

    // E3
    boolean existsByTripPlan(TripPlan tripPlan);
}
