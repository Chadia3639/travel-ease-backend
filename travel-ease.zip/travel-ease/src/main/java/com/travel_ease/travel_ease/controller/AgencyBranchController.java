package com.travel_ease.travel_ease.controller;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.travel_ease.travel_ease.entity.AgencyBranch;
import com.travel_ease.travel_ease.service.AgencyBranchService;

@RestController
@RequestMapping("/api/agency-branches")
public class AgencyBranchController {

    @Autowired
    private AgencyBranchService agencyBranchService;

    @PostMapping("/save")
    public ResponseEntity<String> saveAgencyBranch(@RequestBody AgencyBranch agencyBranch) {
        String message = agencyBranchService.saveAgencyBranch(agencyBranch);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<AgencyBranch>> getAllAgencyBranches() {
        return new ResponseEntity<>(agencyBranchService.getAllAgencyBranches(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getAgencyBranchById(@PathVariable UUID id) {
        Optional<AgencyBranch> agencyBranch = agencyBranchService.getAgencyBranchById(id);
        if (agencyBranch.isPresent()) {
            return new ResponseEntity<>(agencyBranch.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("The agency branch with that id does not exist", HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateAgencyBranch(@PathVariable UUID id, @RequestBody AgencyBranch agencyBranch) {
        String message = agencyBranchService.updateAgencyBranch(id, agencyBranch);
        if (message.equals("The agency branch with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAgencyBranch(@PathVariable UUID id) {
        String message = agencyBranchService.deleteAgencyBranch(id);
        if (message.equals("The agency branch with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // C2
    @GetMapping("/free")
    public ResponseEntity<List<AgencyBranch>> getFreeAgencyBranches() {
        return new ResponseEntity<>(agencyBranchService.getFreeAgencyBranches(), HttpStatus.OK);
    }
}
