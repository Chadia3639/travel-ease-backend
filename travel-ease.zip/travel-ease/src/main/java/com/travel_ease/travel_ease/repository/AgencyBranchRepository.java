package com.travel_ease.travel_ease.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.travel_ease.travel_ease.entity.AgencyBranch;

@Repository
public interface AgencyBranchRepository extends JpaRepository<AgencyBranch, UUID> {

    // C2
    @Query("SELECT l FROM AgencyBranch l WHERE NOT EXISTS (SELECT p FROM TravelAgent p WHERE p.agencyBranch = l) ORDER BY l.branchNumber")
    List<AgencyBranch> findFreeAgencyBranches();

    // D4
    Optional<AgencyBranch> findByBranchNumber(int branchNumber);
}
