package com.travel_ease.travel_ease.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.travel_ease.travel_ease.entity.AgencyBranch;
import com.travel_ease.travel_ease.entity.TravelAgent;

@Repository
public interface TravelAgentRepository extends JpaRepository<TravelAgent, UUID> {

    // C1
    @Query("SELECT DISTINCT a FROM TravelAgent a JOIN a.travelInterests i WHERE LOWER(i.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<TravelAgent> findByTravelInterestName(@Param("name") String name);

    // D4
    boolean existsByAgencyBranch(AgencyBranch agencyBranch);
}
