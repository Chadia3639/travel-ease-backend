package com.travel_ease.travel_ease.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.travel_ease.travel_ease.entity.TripPlan;
import com.travel_ease.travel_ease.entity.TripStatus;
import com.travel_ease.travel_ease.repository.TripExpenseRepository;
import com.travel_ease.travel_ease.repository.TripPlanRepository;

@Service
public class TripPlanService {

    @Autowired
    private TripPlanRepository tripPlanRepository;

    @Autowired
    private TripExpenseRepository tripExpenseRepository;

    // D1: no past dates, no second departure for the same travel agent, always starts DRAFTED
    public String saveTripPlan(TripPlan tripPlan) {
        if (tripPlan.getDepartureDate().isBefore(LocalDate.now())) {
            return "Trip plan date cannot be in the past";
        }
        if (tripPlan.getTravelAgent() != null && tripPlanRepository.existsByTravelAgentAndDepartureDateAndStatusNot(
                tripPlan.getTravelAgent(), tripPlan.getDepartureDate(), TripStatus.ABANDONED)) {
            return "Travel agent already has a departure on that date";
        }
        tripPlan.setStatus(TripStatus.DRAFTED);
        tripPlanRepository.save(tripPlan);
        return "Trip plan saved successfully";
    }

    public List<TripPlan> getAllTripPlans() {
        return tripPlanRepository.findAll();
    }

    public Optional<TripPlan> getTripPlanById(UUID id) {
        return tripPlanRepository.findById(id);
    }

    public String updateTripPlan(UUID id, TripPlan tripPlan) {
        Optional<TripPlan> existing = tripPlanRepository.findById(id);
        if (existing.isEmpty()) {
            return "The trip plan with that id does not exist";
        }
        TripPlan found = existing.get();
        // the status is not changed here, only through PATCH /{id}/status (D2)
        found.setDepartureDate(tripPlan.getDepartureDate());
        found.setDestination(tripPlan.getDestination());
        found.setBudget(tripPlan.getBudget());
        found.setTraveler(tripPlan.getTraveler());
        found.setTravelAgent(tripPlan.getTravelAgent());
        tripPlanRepository.save(found);
        return "Trip plan updated successfully";
    }

    // E3: a trip plan with trip expenses cannot be deleted
    public String deleteTripPlan(UUID id) {
        Optional<TripPlan> existing = tripPlanRepository.findById(id);
        if (existing.isEmpty()) {
            return "The trip plan with that id does not exist";
        }
        if (tripExpenseRepository.existsByTripPlan(existing.get())) {
            return "That trip plan has trip expenses, delete them first";
        }
        tripPlanRepository.deleteById(id);
        return "Trip plan deleted successfully";
    }

    // D2: DRAFTED -> FINALIZED or ABANDONED, FINALIZED -> TRAVELLED or ABANDONED, TRAVELLED and ABANDONED are final
    public String changeTripPlanStatus(UUID id, TripStatus newStatus) {
        Optional<TripPlan> existing = tripPlanRepository.findById(id);
        if (existing.isEmpty()) {
            return "The trip plan with that id does not exist";
        }
        TripPlan tripPlan = existing.get();
        TripStatus current = tripPlan.getStatus();
        boolean allowed = false;
        if (current == TripStatus.DRAFTED && (newStatus == TripStatus.FINALIZED || newStatus == TripStatus.ABANDONED)) {
            allowed = true;
        } else if (current == TripStatus.FINALIZED && (newStatus == TripStatus.TRAVELLED || newStatus == TripStatus.ABANDONED)) {
            allowed = true;
        }
        if (!allowed) {
            return "Cannot change status from " + current + " to " + newStatus;
        }
        tripPlan.setStatus(newStatus);
        tripPlanRepository.save(tripPlan);
        return "Trip plan status updated successfully";
    }

    // Bonus: trip plans page by page
    public Page<TripPlan> getTripPlansPage(Pageable pageable) {
        return tripPlanRepository.findAll(pageable);
    }

    // F1
    public List<Object[]> getTripPlanCountPerStatus() {
        return tripPlanRepository.countTripPlansPerStatus();
    }

    // F2: one UPDATE query, no loop
    @Transactional
    public String cancelDayOfTravelAgent(UUID travelAgentId, LocalDate date) {
        int cancelled = tripPlanRepository.cancelDayOfTravelAgent(travelAgentId, date);
        return cancelled + " trip plans cancelled";
    }

    // B2
    public List<TripPlan> getTripPlansByStatus(TripStatus status) {
        return tripPlanRepository.findByStatusOrderByDepartureDateAsc(status);
    }

    // B3
    public List<TripPlan> getTripPlansBetween(LocalDate start, LocalDate end) {
        return tripPlanRepository.findByDepartureDateBetweenOrderByDepartureDateAsc(start, end);
    }
}
