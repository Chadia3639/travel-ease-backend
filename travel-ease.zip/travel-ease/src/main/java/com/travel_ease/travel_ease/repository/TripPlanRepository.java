package com.travel_ease.travel_ease.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.travel_ease.travel_ease.entity.TravelAgent;
import com.travel_ease.travel_ease.entity.TripPlan;
import com.travel_ease.travel_ease.entity.TripStatus;

@Repository
public interface TripPlanRepository extends JpaRepository<TripPlan, UUID> {

    // B2
    List<TripPlan> findByStatusOrderByDepartureDateAsc(TripStatus status);

    // B3
    List<TripPlan> findByDepartureDateBetweenOrderByDepartureDateAsc(LocalDate start, LocalDate end);

    // D1
    boolean existsByTravelAgentAndDepartureDateAndStatusNot(TravelAgent travelAgent, LocalDate departureDate, TripStatus status);

    // F1
    @Query("SELECT e.status, COUNT(e) FROM TripPlan e GROUP BY e.status")
    List<Object[]> countTripPlansPerStatus();

    // F2
    @Modifying
    @Query("UPDATE TripPlan e SET e.status = com.travel_ease.travel_ease.entity.TripStatus.ABANDONED "
            + "WHERE e.travelAgent.id = :travelAgentId AND e.departureDate = :date "
            + "AND e.status <> com.travel_ease.travel_ease.entity.TripStatus.TRAVELLED")
    int cancelDayOfTravelAgent(@Param("travelAgentId") UUID travelAgentId, @Param("date") LocalDate date);

    // Bonus dashboard
    long countByDepartureDate(LocalDate departureDate);

    long countByStatus(TripStatus status);
}
