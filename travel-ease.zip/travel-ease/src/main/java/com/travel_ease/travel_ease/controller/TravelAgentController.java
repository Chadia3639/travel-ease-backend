package com.travel_ease.travel_ease.controller;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.travel_ease.travel_ease.entity.TravelAgent;
import com.travel_ease.travel_ease.service.TravelAgentService;

@RestController
@RequestMapping("/api/travel-agents")
public class TravelAgentController {

    @Autowired
    private TravelAgentService travelAgentService;

    @PostMapping("/save")
    public ResponseEntity<String> saveTravelAgent(@RequestBody TravelAgent travelAgent) {
        String message = travelAgentService.saveTravelAgent(travelAgent);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<TravelAgent>> getAllTravelAgents() {
        return new ResponseEntity<>(travelAgentService.getAllTravelAgents(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTravelAgentById(@PathVariable UUID id) {
        Optional<TravelAgent> travelAgent = travelAgentService.getTravelAgentById(id);
        if (travelAgent.isPresent()) {
            return new ResponseEntity<>(travelAgent.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("The travel agent with that id does not exist", HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateTravelAgent(@PathVariable UUID id, @RequestBody TravelAgent travelAgent) {
        String message = travelAgentService.updateTravelAgent(id, travelAgent);
        if (message.equals("The travel agent with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTravelAgent(@PathVariable UUID id) {
        String message = travelAgentService.deleteTravelAgent(id);
        if (message.equals("The travel agent with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // C1
    @GetMapping("/by-travel-interest")
    public ResponseEntity<List<TravelAgent>> getTravelAgentsByTravelInterest(@RequestParam String name) {
        return new ResponseEntity<>(travelAgentService.getTravelAgentsByTravelInterest(name), HttpStatus.OK);
    }

    // D3
    @PutMapping("/{travelAgentId}/travel-interests/{travelInterestId}")
    public ResponseEntity<String> addTravelInterest(@PathVariable UUID travelAgentId, @PathVariable UUID travelInterestId) {
        String message = travelAgentService.addTravelInterest(travelAgentId, travelInterestId);
        if (message.equals("The travel agent with that id does not exist") || message.equals("That travel interest does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else if (message.equals("The travel agent already has that travel interest")) {
            return new ResponseEntity<>(message, HttpStatus.CONFLICT);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // D4
    @PatchMapping("/{travelAgentId}/agency-branch")
    public ResponseEntity<String> changeAgencyBranch(@PathVariable UUID travelAgentId, @RequestParam int branchNumber) {
        String message = travelAgentService.changeAgencyBranch(travelAgentId, branchNumber);
        if (message.equals("The travel agent with that id does not exist") || message.equals("The agency branch with that branchNumber does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else if (message.equals("That agency branch is taken by another travel agent")) {
            return new ResponseEntity<>(message, HttpStatus.CONFLICT);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }
}
