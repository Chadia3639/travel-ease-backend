package com.travel_ease.travel_ease.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.travel_ease.travel_ease.entity.AgencyBranch;
import com.travel_ease.travel_ease.entity.TravelAgent;
import com.travel_ease.travel_ease.entity.TravelInterest;
import com.travel_ease.travel_ease.repository.AgencyBranchRepository;
import com.travel_ease.travel_ease.repository.TravelAgentRepository;
import com.travel_ease.travel_ease.repository.TravelInterestRepository;

@Service
public class TravelAgentService {

    @Autowired
    private TravelAgentRepository travelAgentRepository;

    @Autowired
    private TravelInterestRepository travelInterestRepository;

    @Autowired
    private AgencyBranchRepository agencyBranchRepository;

    public String saveTravelAgent(TravelAgent travelAgent) {
        travelAgentRepository.save(travelAgent);
        return "Travel agent saved successfully";
    }

    public List<TravelAgent> getAllTravelAgents() {
        return travelAgentRepository.findAll();
    }

    public Optional<TravelAgent> getTravelAgentById(UUID id) {
        return travelAgentRepository.findById(id);
    }

    // Agency branch and travel interests have their own endpoints, so update keeps them
    public String updateTravelAgent(UUID id, TravelAgent travelAgent) {
        Optional<TravelAgent> existing = travelAgentRepository.findById(id);
        if (existing.isEmpty()) {
            return "The travel agent with that id does not exist";
        }
        TravelAgent found = existing.get();
        found.setFirstName(travelAgent.getFirstName());
        found.setLastName(travelAgent.getLastName());
        found.setEmail(travelAgent.getEmail());
        travelAgentRepository.save(found);
        return "Travel agent updated successfully";
    }

    public String deleteTravelAgent(UUID id) {
        if (!travelAgentRepository.existsById(id)) {
            return "The travel agent with that id does not exist";
        }
        travelAgentRepository.deleteById(id);
        return "Travel agent deleted successfully";
    }

    // C1
    public List<TravelAgent> getTravelAgentsByTravelInterest(String name) {
        return travelAgentRepository.findByTravelInterestName(name);
    }

    // D3: TravelAgent owns the many-to-many, so we change its list and save it
    @Transactional
    public String addTravelInterest(UUID travelAgentId, UUID travelInterestId) {
        Optional<TravelAgent> travelAgent = travelAgentRepository.findById(travelAgentId);
        if (travelAgent.isEmpty()) {
            return "The travel agent with that id does not exist";
        }
        Optional<TravelInterest> travelInterest = travelInterestRepository.findById(travelInterestId);
        if (travelInterest.isEmpty()) {
            return "That travel interest does not exist";
        }
        TravelAgent agent = travelAgent.get();
        if (agent.getTravelInterests().contains(travelInterest.get())) {
            return "The travel agent already has that travel interest";
        }
        agent.getTravelInterests().add(travelInterest.get());
        travelAgentRepository.save(agent);
        return "Travel interest added to the travel agent";
    }

    // D4
    public String changeAgencyBranch(UUID travelAgentId, int branchNumber) {
        Optional<TravelAgent> travelAgent = travelAgentRepository.findById(travelAgentId);
        if (travelAgent.isEmpty()) {
            return "The travel agent with that id does not exist";
        }
        Optional<AgencyBranch> agencyBranch = agencyBranchRepository.findByBranchNumber(branchNumber);
        if (agencyBranch.isEmpty()) {
            return "The agency branch with that branchNumber does not exist";
        }
        TravelAgent agent = travelAgent.get();
        AgencyBranch current = agent.getAgencyBranch();
        boolean alreadyHere = current != null && current.getId().equals(agencyBranch.get().getId());
        if (!alreadyHere && travelAgentRepository.existsByAgencyBranch(agencyBranch.get())) {
            return "That agency branch is taken by another travel agent";
        }
        agent.setAgencyBranch(agencyBranch.get());
        travelAgentRepository.save(agent);
        return "Agency branch changed successfully";
    }
}
