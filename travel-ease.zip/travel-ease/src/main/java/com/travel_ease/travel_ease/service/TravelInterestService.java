package com.travel_ease.travel_ease.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel_ease.travel_ease.entity.TravelInterest;
import com.travel_ease.travel_ease.repository.TravelInterestRepository;

@Service
public class TravelInterestService {

    @Autowired
    private TravelInterestRepository travelInterestRepository;

    public String saveTravelInterest(TravelInterest travelInterest) {
        travelInterestRepository.save(travelInterest);
        return "Travel interest saved successfully";
    }

    public List<TravelInterest> getAllTravelInterests() {
        return travelInterestRepository.findAll();
    }

    public Optional<TravelInterest> getTravelInterestById(UUID id) {
        return travelInterestRepository.findById(id);
    }

    public String updateTravelInterest(UUID id, TravelInterest travelInterest) {
        Optional<TravelInterest> existing = travelInterestRepository.findById(id);
        if (existing.isEmpty()) {
            return "The travel interest with that id does not exist";
        }
        TravelInterest found = existing.get();
        found.setName(travelInterest.getName());
        travelInterestRepository.save(found);
        return "Travel interest updated successfully";
    }

    public String deleteTravelInterest(UUID id) {
        if (!travelInterestRepository.existsById(id)) {
            return "The travel interest with that id does not exist";
        }
        travelInterestRepository.deleteById(id);
        return "Travel interest deleted successfully";
    }

    // C3
    public List<TravelInterest> getUnusedTravelInterests() {
        return travelInterestRepository.findUnusedTravelInterests();
    }
}
