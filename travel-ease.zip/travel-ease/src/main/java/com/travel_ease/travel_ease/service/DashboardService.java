package com.travel_ease.travel_ease.service;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel_ease.travel_ease.entity.TripStatus;
import com.travel_ease.travel_ease.repository.AgencyBranchRepository;
import com.travel_ease.travel_ease.repository.TravelAgentRepository;
import com.travel_ease.travel_ease.repository.TravelerRepository;
import com.travel_ease.travel_ease.repository.TripExpenseRepository;
import com.travel_ease.travel_ease.repository.TripPlanRepository;

@Service
public class DashboardService {

    @Autowired
    private TravelerRepository travelerRepository;

    @Autowired
    private TravelAgentRepository travelAgentRepository;

    @Autowired
    private AgencyBranchRepository agencyBranchRepository;

    @Autowired
    private TripPlanRepository tripPlanRepository;

    @Autowired
    private TripExpenseRepository tripExpenseRepository;

    public Map<String, Long> getSummary() {
        Map<String, Long> summary = new LinkedHashMap<>();
        summary.put("travelers", travelerRepository.count());
        summary.put("travelAgents", travelAgentRepository.count());
        summary.put("freeAgencyBranches", (long) agencyBranchRepository.findFreeAgencyBranches().size());
        summary.put("departuresToday", tripPlanRepository.countByDepartureDate(LocalDate.now()));
        summary.put("drafted", tripPlanRepository.countByStatus(TripStatus.DRAFTED));
        summary.put("expenses", tripExpenseRepository.count());
        return summary;
    }
}
