package com.travel_ease.travel_ease.controller;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.travel_ease.travel_ease.entity.Traveler;
import com.travel_ease.travel_ease.service.TravelAgentService;
import com.travel_ease.travel_ease.service.TravelerService;

@RestController
@RequestMapping("/api/travelers")
public class TravelerController {

    @Autowired
    private TravelerService travelerService;

    @Autowired
    private TravelAgentService travelAgentService;

    @PostMapping("/save")
    public ResponseEntity<String> saveTraveler(@RequestBody Traveler traveler) {
        String message = travelerService.saveTraveler(traveler);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Traveler>> getAllTravelers() {
        return new ResponseEntity<>(travelerService.getAllTravelers(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTravelerById(@PathVariable UUID id) {
        Optional<Traveler> traveler = travelerService.getTravelerById(id);
        if (traveler.isPresent()) {
            return new ResponseEntity<>(traveler.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("The traveler with that id does not exist", HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateTraveler(@PathVariable UUID id, @RequestBody Traveler traveler) {
        String message = travelerService.updateTraveler(id, traveler);
        if (message.equals("The traveler with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTraveler(@PathVariable UUID id) {
        String message = travelerService.deleteTraveler(id);
        if (message.equals("The traveler with that id does not exist")) {
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }
    }

    // B1
    @GetMapping("/by-nationality")
    public ResponseEntity<List<Traveler>> getTravelersByNationality(@RequestParam String nationality) {
        return new ResponseEntity<>(travelerService.getTravelersByNationality(nationality), HttpStatus.OK);
    }

    // C4
    @GetMapping("/of-travel-agent/{travelAgentId}")
    public ResponseEntity<?> getTravelersOfTravelAgent(@PathVariable UUID travelAgentId) {
        if (travelAgentService.getTravelAgentById(travelAgentId).isEmpty()) {
            return new ResponseEntity<>("The travel agent with that id does not exist", HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(travelerService.getTravelersOfTravelAgent(travelAgentId), HttpStatus.OK);
        }
    }
}
