package com.travel_ease.travel_ease.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.travel_ease.travel_ease.entity.Traveler;

@Repository
public interface TravelerRepository extends JpaRepository<Traveler, UUID> {

    // B1
    List<Traveler> findByNationalityIgnoreCaseOrderByLastNameAsc(String nationality);

    // C4
    @Query("SELECT DISTINCT t.traveler FROM TripPlan t WHERE t.travelAgent.id = :travelAgentId")
    List<Traveler> findTravelersOfTravelAgent(@Param("travelAgentId") UUID travelAgentId);
}
