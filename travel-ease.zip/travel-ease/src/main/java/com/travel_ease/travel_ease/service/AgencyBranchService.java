package com.travel_ease.travel_ease.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel_ease.travel_ease.entity.AgencyBranch;
import com.travel_ease.travel_ease.repository.AgencyBranchRepository;

@Service
public class AgencyBranchService {

    @Autowired
    private AgencyBranchRepository agencyBranchRepository;

    public String saveAgencyBranch(AgencyBranch agencyBranch) {
        agencyBranchRepository.save(agencyBranch);
        return "Agency branch saved successfully";
    }

    public List<AgencyBranch> getAllAgencyBranches() {
        return agencyBranchRepository.findAll();
    }

    public Optional<AgencyBranch> getAgencyBranchById(UUID id) {
        return agencyBranchRepository.findById(id);
    }

    public String updateAgencyBranch(UUID id, AgencyBranch agencyBranch) {
        Optional<AgencyBranch> existing = agencyBranchRepository.findById(id);
        if (existing.isEmpty()) {
            return "The agency branch with that id does not exist";
        }
        AgencyBranch found = existing.get();
        found.setBranchNumber(agencyBranch.getBranchNumber());
        found.setName(agencyBranch.getName());
        agencyBranchRepository.save(found);
        return "Agency branch updated successfully";
    }

    public String deleteAgencyBranch(UUID id) {
        if (!agencyBranchRepository.existsById(id)) {
            return "The agency branch with that id does not exist";
        }
        agencyBranchRepository.deleteById(id);
        return "Agency branch deleted successfully";
    }

    // C2
    public List<AgencyBranch> getFreeAgencyBranches() {
        return agencyBranchRepository.findFreeAgencyBranches();
    }
}
