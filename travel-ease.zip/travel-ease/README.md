# TravelEase Backend

- **Student:** Uwamahoro Rwema Chadia
- **Student ID:** 26752
- **Project:** TravelEase
- **Course:** INSY 8322 Web Technology and Internet, AUCA, mid-term examination

TravelEase helps travelers plan personalised trips in Rwanda. A traveler opens a trip plan
prepared by a travel agent, who works in one agency branch and holds one or more travel
interests. A trip plan moves from DRAFTED to FINALIZED and ends TRAVELLED or ABANDONED.
Once a trip plan is TRAVELLED, its trip expenses are recorded.

Built with Spring Boot, Spring Data JPA and PostgreSQL.

## Requirements

- Java 17 or newer
- PostgreSQL running on `localhost:5432`
- Maven is not needed. The project includes the Maven wrapper (`mvnw` / `mvnw.cmd`).

## Steps to run the API

1. Create the PostgreSQL database named in `src/main/resources/application.properties`:
   ```sql
   CREATE DATABASE travel_ease_db;
   ```
   The connection settings (database `travel_ease_db`, user `postgres`) are in
   `application.properties`.
2. Start the API from the project folder:
   ```bash
   ./mvnw spring-boot:run
   ```
   On Windows (cmd / PowerShell): `mvnw.cmd spring-boot:run`
3. The API runs at `http://localhost:8080/api`. Hibernate creates the tables, foreign keys and
   the join table `travel_agent_travel_interest` (`ddl-auto=update`). The SQL is printed in the
   console (`show-sql=true`).

## Testing with Postman

1. Import `travel-ease-midterm.postman_collection.json` (Postman: Import, then choose the file).
2. With the API running on an **empty** `travel_ease_db`, open the collection and click
   **Run** (Collection Runner). Keep the order.
   - **0 Seed data (Step 0)** enters the seed data through the API's own save endpoints:
     4 travel interests, 4 agency branches, 3 travel agents, 5 travelers and 10 trip plans
     in all four statuses. It stores every generated id in collection variables, so
     no id has to be copied by hand.
   - Each requirement then has requests named by its ID (A1, A2, B1 ... F2, BONUS), with its
     success case and its failing cases (404 / 400 / 409). Every request has Postman tests
     that check the HTTP status and the exact message.
3. After one full run, any single request can be sent again by hand. The variables keep the ids.
4. To run the whole collection a second time, empty the database first
   (`DROP DATABASE travel_ease_db; CREATE DATABASE travel_ease_db;`), then restart the API.
   Passport numbers are unique, so the seed cannot be entered twice.

The collection was run with Newman, Postman's command-line runner, against an empty database:
119 requests, 231 assertions, 0 failures.

## Project structure

```
entity/      Traveler, TravelAgent, TravelInterest, AgencyBranch, TripPlan, TripStatus, TripExpense
repository/  one JpaRepository per entity (derived queries and @Query JPQL)
service/     one service per entity + DashboardService; services return List, Optional or a String message
controller/  one controller per entity + DashboardController; maps each message to an HttpStatus
```

## Endpoints

| ID | Method and path | Query type |
|----|-----------------|------------|
| A2 | `POST /save`, `GET /all`, `GET /{id}`, `PUT /update/{id}`, `DELETE /delete/{id}` on `/api/travel-interests`, `/api/agency-branches`, `/api/travel-agents`, `/api/travelers`, `/api/trip-plans` | CRUD |
| B1 | `GET /api/travelers/by-nationality?nationality=rwandan` | Derived |
| B2 | `GET /api/trip-plans/by-status?status=DRAFTED` | Derived |
| B3 | `GET /api/trip-plans/between?start=2026-10-01&end=2026-10-31` | Derived |
| C1 | `GET /api/travel-agents/by-travel-interest?name=advent` | JPQL |
| C2 | `GET /api/agency-branches/free` | JPQL |
| C3 | `GET /api/travel-interests/unused` | JPQL |
| C4 | `GET /api/travelers/of-travel-agent/{travelAgentId}` | JPQL |
| D1 | `POST /api/trip-plans/save` | Rule + derived |
| D2 | `PATCH /api/trip-plans/{id}/status?status=FINALIZED` | Rule |
| D3 | `PUT /api/travel-agents/{travelAgentId}/travel-interests/{travelInterestId}` | Many-to-many |
| D4 | `PATCH /api/travel-agents/{travelAgentId}/agency-branch?branchNumber=4` | Rule + derived |
| E1 | `POST /api/trip-expenses/save?tripPlanId=...` | New entity |
| E2 | `GET /api/trip-expenses/traveler/{passportNumber}` | JPQL |
| E3 | `DELETE /api/trip-expenses/delete/{id}` and `DELETE /api/trip-plans/delete/{id}` | CRUD + derived |
| F1 | `GET /api/trip-plans/stats/by-status` | JPQL GROUP BY |
| F2 | `PATCH /api/trip-plans/cancel-day?travelAgentId=...&date=2026-10-20` | JPQL UPDATE |
| Bonus | `GET /api/dashboard/summary` | count / countBy |
| Bonus | `GET /api/trip-plans/page?page=0&size=5&sort=departureDate,desc` | Pageable |

## Seed data note

A new trip plan cannot be saved with a past date (D1). To enter the seed data on any day,
the collection saves each trip plan with a future date (today + N days), moves it through the
allowed status changes with `PATCH /{id}/status`, and then gives it its October/November
2026 date with the general `PUT /update/{id}`. That includes the two trip plans of the same travel
agent on 2026-10-20, one of them ABANDONED. The second of those two is saved after the
first one is ABANDONED, which D1 allows.
